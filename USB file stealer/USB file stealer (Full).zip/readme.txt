FOR EDUCATION PURPOSE ONLY

Make a shortcut of _start_.bat (you can go into properties and change it so it opens as a minimized program)
change the var of the files(s) you want to 'steal' in _config_.bat
be sure to have a big enough usb drive, I reccommend 32 to 64gb but you could also get away with 16gb if you aren't 'stealing' a lot.
the copied file are located in "UsbDriveLetter:\Stolenfiles\randomnumbers\"

!!WARNING!!
FOR EDUCATION PURPOSE ONLY
I'm not accountable if you do anything stupid and or illegal with these files.

I made this to show how easy it is for thieves/hackers to steal your data if you keep your pc/laptop unlocked and are away for like 5 minutes.
These files could be changed so the steal saved browser passwords and other stuff.
So look out and stay safe in the real world and online.

Have a nice day :^)
!!WARNING!!